/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { jsPDF } from 'jspdf';
import { ComicStory } from '../types/comic';

/**
 * Loads an image (data URL or external URL) onto a canvas and returns a PNG data URL
 * to ensure jsPDF can embed it reliably regardless of SVG or format.
 */
async function getRasterDataUrl(url: string): Promise<string | null> {
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.crossOrigin = 'Anonymous';
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.naturalWidth || 800;
          canvas.height = img.naturalHeight || 533;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(url);
            return;
          }
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);
          resolve(canvas.toDataURL('image/jpeg', 0.9));
        } catch (e) {
          console.warn('Canvas rasterization error:', e);
          resolve(url);
        }
      };
      img.onerror = () => {
        console.warn('Image load error for PDF:', url.substring(0, 50));
        resolve(null);
      };
      img.src = url;
    } catch {
      resolve(null);
    }
  });
}

export async function exportComicToPdf(story: ComicStory): Promise<void> {
  // A4 dimensions: 210 x 297 mm
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 14;
  const contentWidth = pageWidth - margin * 2;

  // Pre-rasterize all panel images
  const rasterizedImages: (string | null)[] = [];
  for (const panel of story.panels) {
    if (panel.imageUrl) {
      const raster = await getRasterDataUrl(panel.imageUrl);
      rasterizedImages.push(raster);
    } else {
      rasterizedImages.push(null);
    }
  }

  // --- COVER / INTRO PAGE ---
  drawComicHeader(doc, margin, contentWidth, story);

  let currentY = 70;

  // Draw Panel 1 on Page 1
  if (story.panels[0]) {
    drawPanelToDoc(doc, story.panels[0], rasterizedImages[0], margin, currentY, contentWidth, 205);
  }

  // --- PAGE 2: Panel 2 & Panel 3 ---
  doc.addPage();
  drawPageHeader(doc, story.title, 2);
  currentY = 22;
  const panelHeightHalf = (pageHeight - currentY - margin - 6) / 2;

  if (story.panels[1]) {
    drawPanelToDoc(doc, story.panels[1], rasterizedImages[1], margin, currentY, contentWidth, panelHeightHalf);
  }
  if (story.panels[2]) {
    drawPanelToDoc(doc, story.panels[2], rasterizedImages[2], margin, currentY + panelHeightHalf + 6, contentWidth, panelHeightHalf);
  }

  // --- PAGE 3: Panel 4 & Panel 5 ---
  doc.addPage();
  drawPageHeader(doc, story.title, 3);
  currentY = 22;

  if (story.panels[3]) {
    drawPanelToDoc(doc, story.panels[3], rasterizedImages[3], margin, currentY, contentWidth, panelHeightHalf);
  }
  if (story.panels[4]) {
    drawPanelToDoc(doc, story.panels[4], rasterizedImages[4], margin, currentY + panelHeightHalf + 6, contentWidth, panelHeightHalf);
  }

  // Save the PDF file
  const sanitizedTitle = story.title.toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').slice(0, 30);
  doc.save(`comiccraft-${sanitizedTitle || 'story'}.pdf`);
}

function drawComicHeader(doc: jsPDF, margin: number, width: number, story: ComicStory) {
  // Top yellow banner
  doc.setFillColor(254, 240, 138); // amber-200
  doc.rect(margin, 12, width, 10, 'F');
  doc.setDrawColor(15, 23, 42); // slate-900
  doc.setLineWidth(0.8);
  doc.rect(margin, 12, width, 10, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(180, 83, 9); // amber-700
  doc.text('★ COMICCRAFT EXCLUSIVE ★ AI COMIC STORY CREATOR', margin + width / 2, 18.5, { align: 'center' });

  // Main Story Title Box
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(margin, 24, width, 20, 'F');
  doc.setDrawColor(245, 158, 11);
  doc.setLineWidth(1);
  doc.rect(margin, 24, width, 20, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(255, 255, 255);
  const truncatedTitle = doc.splitTextToSize(story.title.toUpperCase(), width - 10);
  doc.text(truncatedTitle[0] || story.title, margin + width / 2, 36, { align: 'center' });

  // Metadata Pill Grid Box
  doc.setFillColor(248, 250, 252);
  doc.rect(margin, 46, width, 18, 'F');
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.6);
  doc.rect(margin, 46, width, 18, 'S');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);

  const col1X = margin + 4;
  const col2X = margin + width * 0.32;
  const col3X = margin + width * 0.62;

  doc.setFont('helvetica', 'bold');
  doc.text('HERO:', col1X, 52);
  doc.setFont('helvetica', 'normal');
  doc.text(`${story.characterProfile.name}`, col1X + 13, 52);

  doc.setFont('helvetica', 'bold');
  doc.text('SETTING:', col2X, 52);
  doc.setFont('helvetica', 'normal');
  doc.text(`${story.input.setting}`, col2X + 17, 52);

  doc.setFont('helvetica', 'bold');
  doc.text('TONE:', col3X, 52);
  doc.setFont('helvetica', 'normal');
  doc.text(`${story.input.tone}`, col3X + 12, 52);

  doc.setFont('helvetica', 'bold');
  doc.text('STYLE:', col1X, 60);
  doc.setFont('helvetica', 'normal');
  doc.text(`${story.input.artStyle}`, col1X + 13, 60);

  doc.setFont('helvetica', 'bold');
  doc.text('LOGLINE:', col2X, 60);
  doc.setFont('helvetica', 'italic');
  const shortLogline = doc.splitTextToSize(story.logline, width - (col2X - margin) - 4);
  doc.text(shortLogline[0] || story.logline, col2X + 17, 60);
}

function drawPageHeader(doc: jsPDF, title: string, pageNumber: number) {
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`COMICCRAFT · ${title.toUpperCase()}`, 14, 12);
  doc.text(`PAGE ${pageNumber} OF 3`, 196, 12, { align: 'right' });
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.3);
  doc.line(14, 15, 196, 15);
}

function drawPanelToDoc(
  doc: jsPDF,
  panel: any,
  imgDataUrl: string | null,
  x: number,
  y: number,
  width: number,
  height: number
) {
  // Panel Outer Frame with thick comic border
  doc.setFillColor(255, 255, 255);
  doc.rect(x, y, width, height, 'F');
  doc.setDrawColor(15, 23, 42); // Black comic border
  doc.setLineWidth(1.2);
  doc.rect(x, y, width, height, 'S');

  // Panel Header Ribbon
  doc.setFillColor(15, 23, 42);
  doc.rect(x, y, width, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(254, 240, 138); // Yellow badge
  doc.text(`PANEL ${panel.panel_number}: ${panel.title.toUpperCase()}`, x + 4, y + 5.5);

  const innerX = x + 3;
  const innerY = y + 10;
  const innerWidth = width - 6;

  // Split Panel into Image area (left or top) and Text area
  // For landscape format: image on left, narrative & dialogue on right!
  const imgWidth = innerWidth * 0.48;
  const imgHeight = height - 14;

  if (imgDataUrl) {
    try {
      doc.addImage(imgDataUrl, 'JPEG', innerX, innerY, imgWidth, imgHeight);
      doc.setDrawColor(15, 23, 42);
      doc.setLineWidth(0.6);
      doc.rect(innerX, innerY, imgWidth, imgHeight, 'S');
    } catch {
      drawPlaceholderImageBox(doc, innerX, innerY, imgWidth, imgHeight, panel.panel_number);
    }
  } else {
    drawPlaceholderImageBox(doc, innerX, innerY, imgWidth, imgHeight, panel.panel_number);
  }

  // Right column: Narrator caption + Dialogue bubbles + Scene description
  const textX = innerX + imgWidth + 4;
  const textWidth = innerWidth - imgWidth - 4;
  let textY = innerY;

  // 1. Narrator Box (Classic yellow comic caption)
  if (panel.narration) {
    doc.setFillColor(254, 243, 199); // amber-100
    const narrationLines = doc.splitTextToSize(`"${panel.narration}"`, textWidth - 6);
    const boxHeight = Math.max(12, narrationLines.length * 3.8 + 6);

    doc.rect(textX, textY, textWidth, boxHeight, 'F');
    doc.setDrawColor(15, 23, 42);
    doc.setLineWidth(0.5);
    doc.rect(textX, textY, textWidth, boxHeight, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6.5);
    doc.setTextColor(180, 83, 9);
    doc.text('NARRATOR', textX + 3, textY + 3.8);

    doc.setFont('times', 'italic');
    doc.setFontSize(7.5);
    doc.setTextColor(30, 41, 59);
    doc.text(narrationLines, textX + 3, textY + 7.5);

    textY += boxHeight + 3;
  }

  // 2. Character Dialogue Bubbles
  if (panel.dialogue && panel.dialogue.length > 0) {
    for (const d of panel.dialogue) {
      if (textY > y + height - 20) break; // prevent overflow

      doc.setFillColor(241, 245, 249);
      const dialogueLines = doc.splitTextToSize(`"${d.text}"`, textWidth - 6);
      const dBoxHeight = Math.max(10, dialogueLines.length * 3.6 + 6);

      doc.roundedRect(textX, textY, textWidth, dBoxHeight, 2, 2, 'F');
      doc.setDrawColor(15, 23, 42);
      doc.setLineWidth(0.5);
      doc.roundedRect(textX, textY, textWidth, dBoxHeight, 2, 2, 'S');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(6.5);
      doc.setTextColor(2, 132, 199);
      doc.text(d.character.toUpperCase(), textX + 3, textY + 3.8);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(15, 23, 42);
      doc.text(dialogueLines, textX + 3, textY + 7.5);

      textY += dBoxHeight + 2.5;
    }
  }

  // 3. Scene description note at bottom
  if (panel.scene_description && textY < y + height - 12) {
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(6);
    doc.setTextColor(100, 116, 139);
    doc.text('SCENE:', textX, textY + 4);

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(6.5);
    const sceneLines = doc.splitTextToSize(panel.scene_description, textWidth - 12);
    doc.text(sceneLines.slice(0, 3), textX + 12, textY + 4);
  }
}

function drawPlaceholderImageBox(doc: jsPDF, x: number, y: number, w: number, h: number, panelNum: number) {
  doc.setFillColor(226, 232, 240);
  doc.rect(x, y, w, h, 'F');
  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.5);
  doc.rect(x, y, w, h, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(100, 116, 139);
  doc.text(`[PANEL ${panelNum} ART]`, x + w / 2, y + h / 2, { align: 'center' });
}
