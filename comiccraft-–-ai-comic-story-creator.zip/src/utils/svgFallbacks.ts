/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

interface FallbackParams {
  panelNumber: number;
  title: string;
  setting: string;
  artStyle: string;
  characterName: string;
  sceneDescription: string;
}

/**
 * Generates an SVG data URL for a stylized comic panel illustration
 * Used as a dependable fallback when image generation API limits or model unavailability occurs.
 */
export function generateSvgComicFallback({
  panelNumber,
  title,
  setting,
  artStyle,
  characterName,
  sceneDescription,
}: FallbackParams): string {
  // Palette based on setting
  let bgGradientStart = '#1e1b4b';
  let bgGradientEnd = '#4338ca';
  let accentColor = '#f59e0b';
  let secondaryColor = '#38bdf8';
  let scenerySvg = '';

  const settingLower = (setting || '').toLowerCase();

  if (settingLower.includes('forest')) {
    bgGradientStart = '#064e3b';
    bgGradientEnd = '#047857';
    accentColor = '#34d399';
    secondaryColor = '#facc15';
    scenerySvg = `
      <!-- Trees & foliage -->
      <path d="M40 380 L80 260 L120 380 Z" fill="#022c22" opacity="0.8"/>
      <path d="M100 390 L150 240 L200 390 Z" fill="#065f46" opacity="0.9"/>
      <path d="M480 390 L530 230 L580 390 Z" fill="#022c22" opacity="0.8"/>
      <path d="M420 390 L470 270 L520 390 Z" fill="#065f46" opacity="0.9"/>
      <circle cx="300" cy="180" r="45" fill="#fef08a" opacity="0.8" filter="blur(4px)"/>
      <circle cx="300" cy="180" r="35" fill="#ffffff" opacity="0.9"/>
      <!-- Glowing magical specks -->
      <circle cx="180" cy="280" r="4" fill="#a7f3d0" />
      <circle cx="240" cy="220" r="3" fill="#fef08a" />
      <circle cx="380" cy="250" r="5" fill="#a7f3d0" />
      <circle cx="430" cy="310" r="3" fill="#fde047" />
    `;
  } else if (settingLower.includes('space')) {
    bgGradientStart = '#0f172a';
    bgGradientEnd = '#1e1b4b';
    accentColor = '#38bdf8';
    secondaryColor = '#c084fc';
    scenerySvg = `
      <!-- Distant planet & nebula -->
      <circle cx="480" cy="130" r="70" fill="url(#planetGrad)"/>
      <ellipse cx="480" cy="130" rx="95" ry="18" fill="none" stroke="#f472b6" stroke-width="5" transform="rotate(-25 480 130)" opacity="0.8"/>
      <!-- Stars -->
      <circle cx="80" cy="60" r="2.5" fill="#ffffff"/>
      <circle cx="150" cy="110" r="1.5" fill="#bae6fd"/>
      <circle cx="260" cy="50" r="3" fill="#fef08a"/>
      <circle cx="320" cy="140" r="2" fill="#ffffff"/>
      <circle cx="100" cy="220" r="2" fill="#ffffff"/>
      <circle cx="540" cy="260" r="1.5" fill="#a7f3d0"/>
      <!-- Sci-fi cockpit / viewport frame -->
      <path d="M0 0 L140 0 L80 80 L0 100 Z" fill="#334155" opacity="0.6"/>
      <path d="M600 0 L460 0 L520 80 L600 100 Z" fill="#334155" opacity="0.6"/>
    `;
  } else if (settingLower.includes('city')) {
    bgGradientStart = '#0f172a';
    bgGradientEnd = '#2e1065';
    accentColor = '#f43f5e';
    secondaryColor = '#06b6d4';
    scenerySvg = `
      <!-- Neon Skyline -->
      <rect x="50" y="160" width="70" height="240" fill="#1e293b"/>
      <rect x="140" y="100" width="90" height="300" fill="#0f172a"/>
      <rect x="250" y="180" width="80" height="220" fill="#1e1b4b"/>
      <rect x="350" y="130" width="100" height="270" fill="#1e293b"/>
      <rect x="470" y="190" width="80" height="210" fill="#0f172a"/>
      <!-- Glowing windows -->
      <circle cx="170" cy="140" r="4" fill="#38bdf8"/>
      <circle cx="190" cy="180" r="4" fill="#f43f5e"/>
      <circle cx="170" cy="220" r="4" fill="#facc15"/>
      <circle cx="380" cy="160" r="4" fill="#a855f7"/>
      <circle cx="410" cy="210" r="4" fill="#38bdf8"/>
      <!-- Neon horizon glow -->
      <line x1="0" y1="360" x2="600" y2="360" stroke="#f43f5e" stroke-width="4" opacity="0.8"/>
    `;
  } else if (settingLower.includes('school')) {
    bgGradientStart = '#1e3a8a';
    bgGradientEnd = '#3b82f6';
    accentColor = '#f59e0b';
    secondaryColor = '#60a5fa';
    scenerySvg = `
      <!-- Classroom / hallway architectural elements -->
      <rect x="80" y="100" width="440" height="180" rx="8" fill="#1e293b" opacity="0.8"/>
      <rect x="100" y="120" width="400" height="140" rx="4" fill="#0f766e" opacity="0.9"/>
      <!-- Chalk equations / sketches -->
      <path d="M130 150 Q160 130 190 150 T250 150" fill="none" stroke="#e0f2fe" stroke-width="2" opacity="0.7"/>
      <text x="140" y="190" fill="#fef08a" font-family="monospace" font-size="16" opacity="0.8">E = mc²  ★  COMIX</text>
      <!-- Floor perspective -->
      <path d="M0 340 L600 340 L500 400 L100 400 Z" fill="#475569" opacity="0.6"/>
    `;
  } else {
    // Fantasy / Default
    bgGradientStart = '#312e81';
    bgGradientEnd = '#701a75';
    accentColor = '#fbbf24';
    secondaryColor = '#ec4899';
    scenerySvg = `
      <!-- Mythic mountains & castles -->
      <path d="M0 380 L150 200 L300 380 Z" fill="#1e1b4b" opacity="0.9"/>
      <path d="M220 380 L380 170 L540 380 Z" fill="#312e81" opacity="0.8"/>
      <path d="M420 380 L520 250 L620 380 Z" fill="#4c1d95" opacity="0.9"/>
      <!-- Twin Moons / Sun -->
      <circle cx="220" cy="110" r="35" fill="#fef08a" opacity="0.9"/>
      <circle cx="380" cy="80" r="20" fill="#f472b6" opacity="0.7"/>
    `;
  }

  // Hero silhouette / character anchor in center
  const characterSilhouette = `
    <!-- Character central silhouette with aura -->
    <g transform="translate(300, 275)">
      <!-- Backlight glow -->
      <ellipse cx="0" cy="10" rx="65" ry="85" fill="${accentColor}" opacity="0.4" filter="blur(6px)"/>
      <ellipse cx="0" cy="10" rx="50" ry="70" fill="${secondaryColor}" opacity="0.3"/>
      <!-- Head -->
      <circle cx="0" cy="-35" r="26" fill="#0f172a"/>
      <!-- Torso -->
      <path d="M-22 -10 C-25 35, -35 75, -28 90 L28 90 C35 75, 25 35, 22 -10 Z" fill="#0f172a"/>
      <!-- Dynamic arms / action pose -->
      <path d="M-22 0 L-45 35 L-55 70" stroke="#0f172a" stroke-width="12" stroke-linecap="round"/>
      <path d="M22 0 L48 25 L60 5" stroke="#0f172a" stroke-width="12" stroke-linecap="round"/>
      <!-- Head accessory / hair tuft / visor hint -->
      <path d="M-15 -55 Q0 -70 15 -55" stroke="${accentColor}" stroke-width="4" fill="none"/>
    </g>
  `;

  // Dynamic Comic Action Lines & Speed lines
  const comicRays = `
    <g stroke="#ffffff" stroke-width="1.5" opacity="0.25">
      <line x1="0" y1="0" x2="220" y2="180" />
      <line x1="600" y1="0" x2="380" y2="180" />
      <line x1="0" y1="400" x2="220" y2="300" />
      <line x1="600" y1="400" x2="380" y2="300" />
      <line x1="300" y1="0" x2="300" y2="120" />
    </g>
  `;

  // Comic border effect and halftone dot pattern overlay
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 400" width="100%" height="100%">
      <defs>
        <linearGradient id="bgGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="${bgGradientStart}"/>
          <stop offset="100%" stop-color="${bgGradientEnd}"/>
        </linearGradient>
        <linearGradient id="planetGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#ec4899"/>
          <stop offset="100%" stop-color="#8b5cf6"/>
        </linearGradient>
        <pattern id="halftone" x="0" y="0" width="12" height="12" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1.5" fill="#ffffff" opacity="0.12"/>
        </pattern>
      </defs>

      <!-- Background Sky -->
      <rect width="600" height="400" fill="url(#bgGrad)"/>
      <rect width="600" height="400" fill="url(#halftone)"/>

      <!-- Scenery Layers -->
      ${scenerySvg}

      <!-- Speed & Action lines -->
      ${comicRays}

      <!-- Character Silhouette -->
      ${characterSilhouette}

      <!-- Ground plane / baseline shadow -->
      <ellipse cx="300" cy="370" rx="140" ry="18" fill="#000000" opacity="0.4"/>

      <!-- Stylized Comic Style Badge in top-left -->
      <rect x="16" y="16" width="120" height="30" rx="4" fill="#0f172a" stroke="#f59e0b" stroke-width="2"/>
      <text x="76" y="36" fill="#fef08a" font-family="sans-serif" font-weight="900" font-size="12" text-anchor="middle" letter-spacing="1">PANEL ${panelNumber}</text>

      <!-- Panel Title Banner -->
      <rect x="16" y="348" width="568" height="36" rx="4" fill="#0f172a" opacity="0.88" stroke="#334155" stroke-width="1.5"/>
      <text x="32" y="371" fill="#f8fafc" font-family="sans-serif" font-weight="700" font-size="14" letter-spacing="0.5">
        ${escapeXml(title)}
      </text>
      <text x="568" y="371" fill="#f59e0b" font-family="sans-serif" font-weight="700" font-size="11" text-anchor="end">
        ${escapeXml(artStyle)}
      </text>

      <!-- Inner Comic Frame Border -->
      <rect x="4" y="4" width="592" height="392" fill="none" stroke="#0f172a" stroke-width="6"/>
      <rect x="8" y="8" width="584" height="384" fill="none" stroke="#ffffff" stroke-width="1.5" opacity="0.4"/>
    </svg>
  `;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function escapeXml(unsafe: string): string {
  if (!unsafe) return '';
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}
