/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface OptionItem {
  id: string;
  name: string;
  description: string;
  iconName?: string;
  themeColor: string;
}

export const SETTINGS: OptionItem[] = [
  { id: 'Forest', name: 'Enchanted Forest', description: 'Towering ancient trees, bioluminescent moss, mist, and woodland magic', themeColor: '#10b981' },
  { id: 'School', name: 'High School / Academy', description: 'Lockers, chalkboard classrooms, hallways, and vibrant campus life', themeColor: '#3b82f6' },
  { id: 'City', name: 'Cyberpunk / Modern City', description: 'Neon skyscrapers, rainy asphalt, bustling crosswalks, and rooftop vistas', themeColor: '#8b5cf6' },
  { id: 'Space', name: 'Deep Space & Starship', description: 'Cosmic nebulae, planetary rings, spaceship bridge, and zero-gravity decks', themeColor: '#06b6d4' },
  { id: 'Fantasy World', name: 'Fantasy Kingdom', description: 'Floating islands, stone castles, dragon roosts, and ancient spell rune gates', themeColor: '#f59e0b' },
  { id: 'Desert Ruins', name: 'Desert Ruins & Oasis', description: 'Golden sand dunes, forgotten catacombs, sun-baked sandstone, and mirages', themeColor: '#d97706' },
  { id: 'Undersea Kingdom', name: 'Undersea Kingdom', description: 'Coral reefs, glowing deep sea trenches, sunken galleons, and bubble domes', themeColor: '#0ea5e9' },
];

export const TONES: OptionItem[] = [
  { id: 'Adventure', name: 'High Adventure', description: 'Thrilling quests, peril, courage, and discoveries', themeColor: '#f97316' },
  { id: 'Funny', name: 'Comedic / Funny', description: 'Slapstick timing, witty retorts, playful mishaps, and humor', themeColor: '#eab308' },
  { id: 'Dramatic', name: 'Dramatic & Intense', description: 'High emotional stakes, moral dilemmas, and gripping tension', themeColor: '#ef4444' },
  { id: 'Light-hearted', name: 'Light-hearted & Cozy', description: 'Warm friendships, cheerful days, comfort, and sweet moments', themeColor: '#ec4899' },
  { id: 'Poetic', name: 'Poetic & Mysterious', description: 'Lyrical reflections, dreamlike atmosphere, wonder, and symbolism', themeColor: '#a855f7' },
  { id: 'Superhero', name: 'Superhero Action', description: 'Bold heroics, superpowers, villains, and saving the day', themeColor: '#3b82f6' },
];

export const ART_STYLES: OptionItem[] = [
  { id: 'Comic Book', name: 'Classic American Comic', description: 'Bold inked lines, dynamic shadows, Ben-Day dots, vibrant primary colors', themeColor: '#dc2626' },
  { id: 'Anime', name: 'Anime / Manga', description: 'Expressive large eyes, dynamic action lines, cel-shaded lighting, cinematic angles', themeColor: '#9333ea' },
  { id: 'Pixel Art', name: '16-Bit Pixel Art', description: 'Charming retro pixel sprites, vibrant limited palette, nostalgic game aesthetic', themeColor: '#16a34a' },
  { id: 'Cartoon', name: 'Saturday Morning Cartoon', description: 'Playful curves, expressive exaggerated anatomy, cheerful saturated hues', themeColor: '#ea580c' },
  { id: 'Realistic', name: 'Graphic Novel Realism', description: 'Textured oil painting feel, realistic anatomy, dramatic cinematic chiaroscuro', themeColor: '#475569' },
  { id: 'Watercolor', name: 'Whimsical Watercolor', description: 'Soft paint bleeds, delicate ink outlines, pastel washes, storybook charm', themeColor: '#0891b2' },
];

export const EXAMPLE_STORIES = [
  {
    title: 'The Whispering Portal',
    prompt: 'A brave young fox discovers a mysterious glowing wooden door buried beneath roots in an enchanted forest.',
    characterName: 'Luna',
    setting: 'Forest',
    tone: 'Adventure',
    artStyle: 'Comic Book',
  },
  {
    title: 'The Zero-Gravity Cat',
    prompt: 'A mischievous orange tabby sneaks aboard a deep-space science shuttle and accidentally triggers the gravity reversal switch.',
    characterName: 'Barnaby',
    setting: 'Space',
    tone: 'Funny',
    artStyle: 'Cartoon',
  },
  {
    title: 'The Clockwork Alchemist',
    prompt: 'A quiet student creates a pocket watch that rewinds the last five minutes during an arcane alchemy exam.',
    characterName: 'Aiden',
    setting: 'School',
    tone: 'Dramatic',
    artStyle: 'Anime',
  },
  {
    title: 'Guardian of the Sunken Spire',
    prompt: 'An armored turtle warrior defends a sacred crystalline pearl from robotic scavenger drones in the oceanic deep.',
    characterName: 'Shelldon',
    setting: 'Undersea Kingdom',
    tone: 'Superhero',
    artStyle: 'Comic Book',
  },
];

export const COMIC_SFX = ['POW!', 'BAM!', 'WHOOSH!', 'CRASH!', 'ZAP!', 'KABOOM!', 'SWOOSH!', 'CLICK!'];
