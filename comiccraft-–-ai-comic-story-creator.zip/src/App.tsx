/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ComicInput, ComicStory, GenerationState } from './types/comic';
import { Header } from './components/Header';
import { ComicForm } from './components/ComicForm';
import { GenerationLoader } from './components/GenerationLoader';
import { ComicPreview } from './components/ComicPreview';
import { ErrorMessage } from './components/ErrorMessage';

const STORAGE_KEY = 'comiccraft_current_story';
const LAST_INPUT_KEY = 'comiccraft_last_input';

export default function App() {
  const [currentStory, setCurrentStory] = useState<ComicStory | null>(null);
  const [lastInput, setLastInput] = useState<ComicInput | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [generationState, setGenerationState] = useState<GenerationState>({
    isGenerating: false,
    step: 'idle',
    stepMessage: '',
    progress: 0,
  });

  // Restore saved comic from localStorage on load if available
  useEffect(() => {
    try {
      const savedStory = localStorage.getItem(STORAGE_KEY);
      if (savedStory) {
        const parsed = JSON.parse(savedStory);
        if (parsed && parsed.panels && parsed.panels.length > 0) {
          setCurrentStory(parsed);
        }
      }

      const savedInput = localStorage.getItem(LAST_INPUT_KEY);
      if (savedInput) {
        setLastInput(JSON.parse(savedInput));
      }
    } catch (e) {
      console.warn('Failed to load saved state from localStorage:', e);
    }
  }, []);

  const handleGenerateComic = async (input: ComicInput) => {
    try {
      setError(null);
      setLastInput(input);
      try {
        localStorage.setItem(LAST_INPUT_KEY, JSON.stringify(input));
      } catch {}

      setGenerationState({
        isGenerating: true,
        step: 'outline',
        stepMessage: 'Creating your story...',
        progress: 15,
      });

      const response = await fetch('/api/comic/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(input),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate comic story. Please try again.');
      }

      const story: ComicStory = data.comic;
      setCurrentStory(story);

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(story));
      } catch (e) {
        console.warn('Could not store full story to localStorage:', e);
      }

      setGenerationState({
        isGenerating: false,
        step: 'complete',
        stepMessage: 'Comic created!',
        progress: 100,
      });

      // Smooth scroll to top to see newly generated comic
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err: any) {
      console.error('Generation caught error:', err);
      setError(err?.message || 'Something went wrong while creating your comic. Please try again.');
      setGenerationState({
        isGenerating: false,
        step: 'error',
        stepMessage: 'Error',
        progress: 0,
        error: err?.message,
      });
    }
  };

  const handleRegenerate = () => {
    if (lastInput) {
      handleGenerateComic(lastInput);
    } else if (currentStory) {
      handleGenerateComic(currentStory.input);
    }
  };

  const handleStartNew = () => {
    setCurrentStory(null);
    setError(null);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-amber-50/40 text-slate-900 selection:bg-amber-400 selection:text-slate-900 halftone-bg">
      {/* Global Header */}
      <Header
        onNewComic={handleStartNew}
        showNewButton={!!currentStory && !generationState.isGenerating}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 flex flex-col justify-start">
        {/* Loading State */}
        {generationState.isGenerating && (
          <GenerationLoader
            storyPrompt={lastInput?.storyPrompt || ''}
            characterName={lastInput?.characterName || 'Hero'}
            artStyle={lastInput?.artStyle || 'Comic Book'}
          />
        )}

        {/* Error State */}
        {error && !generationState.isGenerating && (
          <ErrorMessage
            message={error}
            onRetry={lastInput ? handleRegenerate : undefined}
            onNew={handleStartNew}
          />
        )}

        {/* Comic Preview Page */}
        {!generationState.isGenerating && currentStory && (
          <ComicPreview
            story={currentStory}
            onRegenerate={handleRegenerate}
            onNewComic={handleStartNew}
            isRegenerating={generationState.isGenerating}
          />
        )}

        {/* Comic Creation Form (Home Page) */}
        {!generationState.isGenerating && !currentStory && !error && (
          <ComicForm
            onSubmit={handleGenerateComic}
            isLoading={generationState.isGenerating}
            initialValues={lastInput || undefined}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="no-print mt-auto py-6 border-t-3 border-slate-900 bg-white text-center text-xs font-comic text-slate-600">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="font-bold text-slate-800">
            ComicCraft · AI Comic Story Creator
          </p>
          <p className="text-slate-500">
            Turn your imagination into sequential comic book art.
          </p>
        </div>
      </footer>
    </div>
  );
}
