/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ComicInput {
  storyPrompt: string;
  characterName: string;
  setting: string;
  tone: string;
  artStyle: string;
}

export interface Dialogue {
  character: string;
  text: string;
}

export interface ComicPanel {
  panel_number: number;
  title: string;
  scene_description: string;
  narration: string;
  dialogue: Dialogue[];
  image_prompt: string;
  imageUrl?: string;
  imageStatus?: 'loading' | 'ready' | 'fallback' | 'failed';
  imageFallbackReason?: string;
}

export interface CharacterProfile {
  name: string;
  visualAppearance: string;
  signatureClothing: string;
  colorPalette: string;
}

export interface ComicStory {
  id: string;
  title: string;
  logline: string;
  characterProfile: CharacterProfile;
  panels: ComicPanel[];
  input: ComicInput;
  createdAt: string;
}

export type GenerationStep = 'idle' | 'outline' | 'script' | 'images' | 'complete' | 'error';

export interface GenerationState {
  isGenerating: boolean;
  step: GenerationStep;
  stepMessage: string;
  progress: number;
  error?: string;
}
