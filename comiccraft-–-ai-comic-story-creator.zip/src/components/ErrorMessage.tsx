/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AlertTriangle, RotateCw, Wand2 } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
  onRetry?: () => void;
  onNew?: () => void;
}

export const ErrorMessage: React.FC<ErrorMessageProps> = ({
  message,
  onRetry,
  onNew,
}) => {
  return (
    <div className="w-full max-w-xl mx-auto my-12 px-4">
      <div className="bg-red-50 rounded-3xl border-4 border-slate-900 comic-shadow-lg p-6 sm:p-8 text-center relative overflow-hidden">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-red-500 border-3 border-slate-900 flex items-center justify-center comic-shadow-sm mb-4">
          <AlertTriangle className="w-9 h-9 text-white stroke-[2.5]" />
        </div>

        <h3 className="font-bangers text-2xl sm:text-3xl text-slate-900 tracking-wide mb-2 uppercase">
          OOPS! A PLOT TWIST OCCURRED
        </h3>

        <p className="font-comic text-slate-700 text-sm sm:text-base mb-6 leading-relaxed">
          {message || 'Something went wrong while creating your comic. Please try again.'}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          {onRetry && (
            <button
              onClick={onRetry}
              className="w-full sm:w-auto px-6 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bangers text-xl tracking-wider rounded-xl border-3 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <RotateCw className="w-5 h-5" />
              <span>TRY AGAIN</span>
            </button>
          )}

          {onNew && (
            <button
              onClick={onNew}
              className="w-full sm:w-auto px-6 py-3 bg-white hover:bg-slate-100 text-slate-900 font-bangers text-xl tracking-wider rounded-xl border-3 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Wand2 className="w-5 h-5" />
              <span>START NEW COMIC</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
