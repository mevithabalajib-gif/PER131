/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Sparkles, BookOpen, Palette, Feather, Layers } from 'lucide-react';
import { COMIC_SFX } from '../utils/comicThemes';

interface GenerationLoaderProps {
  storyPrompt: string;
  characterName: string;
  artStyle: string;
}

const STAGES = [
  { message: 'Creating your story & character profile...', icon: BookOpen, sfx: 'POW!' },
  { message: 'Designing 5-panel comic narrative arc...', icon: Layers, sfx: 'BAM!' },
  { message: 'Writing character dialogue & narration...', icon: Feather, sfx: 'WHOOSH!' },
  { message: 'Creating detailed illustrations & scene art...', icon: Palette, sfx: 'ZAP!' },
  { message: 'Finishing your comic masterpiece...', icon: Sparkles, sfx: 'KABOOM!' },
];

export const GenerationLoader: React.FC<GenerationLoaderProps> = ({
  storyPrompt,
  characterName,
  artStyle,
}) => {
  const [currentStageIdx, setCurrentStageIdx] = useState(0);
  const [sfxIdx, setSfxIdx] = useState(0);

  useEffect(() => {
    // Progress through stages smoothly
    const stageInterval = setInterval(() => {
      setCurrentStageIdx((prev) => (prev < STAGES.length - 1 ? prev + 1 : prev));
    }, 3800);

    // Fun comic sound effect ticker
    const sfxInterval = setInterval(() => {
      setSfxIdx((prev) => (prev + 1) % COMIC_SFX.length);
    }, 1800);

    return () => {
      clearInterval(stageInterval);
      clearInterval(sfxInterval);
    };
  }, []);

  const activeStage = STAGES[currentStageIdx];
  const CurrentIcon = activeStage.icon;
  const progressPercent = Math.min(100, Math.round(((currentStageIdx + 1) / STAGES.length) * 100));

  return (
    <div className="w-full max-w-2xl mx-auto my-12 px-4">
      <div className="bg-white rounded-3xl border-4 border-slate-900 comic-shadow-lg p-6 sm:p-10 text-center relative overflow-hidden">
        {/* Halftone texture accent */}
        <div className="absolute inset-0 halftone-amber opacity-40 pointer-events-none" />

        {/* Dynamic Comic SFX Burst */}
        <div className="relative inline-block mb-6">
          <div className="absolute -top-6 -right-10 bg-amber-400 text-slate-950 font-bangers text-2xl px-3 py-1 rounded border-2 border-slate-900 comic-shadow-sm rotate-12 animate-pulse">
            {COMIC_SFX[sfxIdx]}
          </div>

          <div className="w-24 h-24 mx-auto rounded-2xl bg-amber-400 border-4 border-slate-900 flex items-center justify-center comic-shadow relative animate-bounce">
            <CurrentIcon className="w-12 h-12 text-slate-950 stroke-[2.5]" />
          </div>
        </div>

        {/* Stage Message */}
        <h2 className="font-bangers text-2xl sm:text-3xl text-slate-900 tracking-wide mb-2 uppercase">
          {activeStage.message}
        </h2>

        <p className="text-sm font-comic text-slate-600 mb-6">
          Breathing life into <strong className="text-slate-900">{characterName}</strong> in{' '}
          <span className="text-amber-600 font-bold">{artStyle}</span> style...
        </p>

        {/* Comic Progress Bar */}
        <div className="w-full bg-slate-100 rounded-full h-5 border-2 border-slate-900 p-0.5 mb-6 overflow-hidden">
          <div
            className="bg-amber-400 h-full rounded-full border-r-2 border-slate-900 transition-all duration-700 ease-out"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Stage Step Indicators */}
        <div className="grid grid-cols-5 gap-2 text-[10px] sm:text-xs font-bangers tracking-wider text-slate-400 uppercase">
          {STAGES.map((stage, idx) => (
            <div
              key={idx}
              className={`p-1.5 rounded border ${
                idx <= currentStageIdx
                  ? 'border-slate-900 bg-amber-100 text-slate-900 font-bold'
                  : 'border-slate-200 bg-slate-50 text-slate-400'
              }`}
            >
              Step {idx + 1}
            </div>
          ))}
        </div>

        {/* Prompt snippet preview */}
        <div className="mt-8 pt-6 border-t-2 border-dashed border-slate-200 text-left">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            Story Premise:
          </span>
          <p className="font-comic italic text-xs text-slate-700 line-clamp-2">
            "{storyPrompt}"
          </p>
        </div>
      </div>
    </div>
  );
};
