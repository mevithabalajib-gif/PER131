/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BookOpen, Sparkles, Wand2 } from 'lucide-react';

interface HeaderProps {
  onNewComic?: () => void;
  showNewButton?: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onNewComic, showNewButton }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-4 border-slate-900 shadow-sm transition-all">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div 
          onClick={onNewComic}
          className="flex items-center gap-3 cursor-pointer group"
          role="button"
          tabIndex={0}
          aria-label="ComicCraft Home"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') onNewComic?.();
          }}
        >
          <div className="w-12 h-12 bg-amber-400 border-3 border-slate-900 rounded-xl flex items-center justify-center comic-shadow-sm group-hover:rotate-[-4deg] transition-transform">
            <BookOpen className="w-7 h-7 text-slate-900 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bangers text-3xl sm:text-4xl text-slate-900 tracking-wider drop-shadow-[1px_1px_0px_#f59e0b]">
                COMICCRAFT
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold font-mono uppercase bg-red-500 text-white px-2 py-0.5 rounded border-2 border-slate-900 -rotate-2">
                <Sparkles className="w-3 h-3" /> AI
              </span>
            </div>
            <p className="text-xs text-slate-600 font-semibold font-outfit -mt-1 hidden xs:block">
              5-Panel Comic Story Creator
            </p>
          </div>
        </div>

        {/* Right Action */}
        <div className="flex items-center gap-3">
          {showNewButton && (
            <button
              onClick={onNewComic}
              className="inline-flex items-center gap-2 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-900 font-bold text-sm rounded-lg border-2 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all cursor-pointer"
            >
              <Wand2 className="w-4 h-4" />
              <span>New Comic</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
