/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { MessageSquare } from 'lucide-react';

interface DialogueBubbleProps {
  character: string;
  text: string;
  isMainCharacter?: boolean;
}

export const DialogueBubble: React.FC<DialogueBubbleProps> = ({
  character,
  text,
  isMainCharacter = false,
}) => {
  return (
    <div className="relative my-2.5 max-w-[92%] sm:max-w-[85%]">
      {/* Speaker Tag */}
      <div className="flex items-center gap-1.5 mb-1 px-1">
        <span
          className={`text-[11px] font-black uppercase tracking-wider px-2 py-0.5 rounded border border-slate-900 ${
            isMainCharacter
              ? 'bg-amber-400 text-slate-950 font-bangers text-xs'
              : 'bg-sky-400 text-slate-950 font-bangers text-xs'
          }`}
        >
          {character}
        </span>
      </div>

      {/* Bubble Container with Comic Tail */}
      <div
        className={`relative px-4 py-3 rounded-2xl border-2 border-slate-900 comic-shadow-sm font-comic text-sm sm:text-base leading-relaxed ${
          isMainCharacter
            ? 'bg-amber-50/90 text-slate-900'
            : 'bg-white text-slate-900'
        }`}
      >
        <p className="font-semibold">{text}</p>

        {/* Comic Speech Bubble Tail */}
        <div
          className={`absolute -bottom-2.5 left-6 w-4 h-4 border-r-2 border-b-2 border-slate-900 rotate-45 ${
            isMainCharacter ? 'bg-amber-50/90' : 'bg-white'
          }`}
        />
      </div>
    </div>
  );
};
