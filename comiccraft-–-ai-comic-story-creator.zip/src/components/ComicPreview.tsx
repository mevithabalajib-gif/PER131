/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ComicStory } from '../types/comic';
import { ComicPanel } from './ComicPanel';
import { exportComicToPdf } from '../utils/pdfExport';
import { 
  RotateCw, 
  Wand2, 
  Download, 
  Printer, 
  Share2, 
  Check, 
  Sparkles, 
  User, 
  Layers, 
  ArrowUp
} from 'lucide-react';

interface ComicPreviewProps {
  story: ComicStory;
  onRegenerate: () => void;
  onNewComic: () => void;
  isRegenerating: boolean;
}

export const ComicPreview: React.FC<ComicPreviewProps> = ({
  story,
  onRegenerate,
  onNewComic,
  isRegenerating,
}) => {
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [copied, setCopied] = useState(false);
  const [regeneratingPanelNum, setRegeneratingPanelNum] = useState<number | null>(null);
  const [localPanels, setLocalPanels] = useState(story.panels);

  // Handle single panel image retry
  const handleRegeneratePanelImage = async (panelNumber: number, prompt: string) => {
    try {
      setRegeneratingPanelNum(panelNumber);
      const characterSummary = `${story.characterProfile.name}: ${story.characterProfile.visualAppearance}`;
      
      const res = await fetch('/api/comic/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imagePrompt: prompt,
          artStyle: story.input.artStyle,
          characterProfileText: characterSummary,
        }),
      });

      const data = await res.json();
      if (data.success && data.imageUrl) {
        setLocalPanels((prev) =>
          prev.map((p) =>
            p.panel_number === panelNumber
              ? { ...p, imageUrl: data.imageUrl, imageStatus: 'ready' }
              : p
          )
        );
      }
    } catch (err) {
      console.error('Failed to regenerate panel image:', err);
    } finally {
      setRegeneratingPanelNum(null);
    }
  };

  const handleDownloadPdf = async () => {
    try {
      setIsExportingPdf(true);
      const storyToExport = { ...story, panels: localPanels };
      await exportComicToPdf(storyToExport);
    } catch (error) {
      console.error('Error downloading PDF:', error);
      alert('Could not export PDF directly. You can also use the "Print Comic" button to save as PDF.');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    const shareText = `Check out my comic "${story.title}" starring ${story.characterProfile.name}! Created with ComicCraft.`;
    if (navigator.clipboard) {
      await navigator.clipboard.writeText(`${shareText}\n\n${story.logline}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8">
      {/* Top Action Toolbar (Sticky or clean banner) */}
      <div className="no-print bg-white/95 backdrop-blur-md rounded-2xl border-4 border-slate-900 comic-shadow p-4 mb-8 flex flex-wrap items-center justify-between gap-4">
        {/* Left: Quick Comic Stats */}
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700">
          <span className="bg-amber-400 text-slate-950 px-2.5 py-1 rounded border border-slate-900 font-bangers text-sm">
            5 PANELS COMPLETE
          </span>
          <span className="hidden sm:inline">·</span>
          <span className="text-slate-600 hidden sm:inline">{story.input.artStyle}</span>
          <span className="hidden sm:inline">·</span>
          <span className="text-slate-600 hidden sm:inline">{story.input.tone}</span>
        </div>

        {/* Right Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Regenerate Comic */}
          <button
            onClick={onRegenerate}
            disabled={isRegenerating}
            className="px-4 py-2 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bangers text-lg tracking-wider rounded-xl border-2 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Regenerate this comic with the same settings"
          >
            <RotateCw className={`w-4 h-4 ${isRegenerating ? 'animate-spin' : ''}`} />
            <span>{isRegenerating ? 'REGENERATING...' : 'REGENERATE COMIC'}</span>
          </button>

          {/* Download PDF */}
          <button
            onClick={handleDownloadPdf}
            disabled={isExportingPdf}
            className="px-4 py-2 bg-red-500 hover:bg-red-400 disabled:opacity-50 text-white font-bangers text-lg tracking-wider rounded-xl border-2 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Download full comic as a formatted PDF"
          >
            <Download className="w-4 h-4" />
            <span>{isExportingPdf ? 'CREATING PDF...' : 'DOWNLOAD PDF'}</span>
          </button>

          {/* Print / Save */}
          <button
            onClick={handlePrint}
            className="hidden sm:inline-flex p-2 text-slate-700 hover:text-slate-950 hover:bg-slate-100 rounded-lg border-2 border-slate-900 transition-colors cursor-pointer"
            title="Print or Save via browser"
          >
            <Printer className="w-5 h-5" />
          </button>

          {/* Share */}
          <button
            onClick={handleShare}
            className="p-2 text-slate-700 hover:text-slate-950 hover:bg-slate-100 rounded-lg border-2 border-slate-900 transition-colors cursor-pointer"
            title="Copy comic story summary"
          >
            {copied ? <Check className="w-5 h-5 text-emerald-600" /> : <Share2 className="w-5 h-5" />}
          </button>

          {/* Start New Comic */}
          <button
            onClick={onNewComic}
            className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-900 font-bangers text-lg tracking-wider rounded-xl border-2 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Wand2 className="w-4 h-4" />
            <span>START NEW</span>
          </button>
        </div>
      </div>

      {/* Comic Story Title Header Box */}
      <div className="bg-slate-900 text-white rounded-3xl border-4 border-slate-900 comic-shadow-lg p-6 sm:p-10 mb-10 relative overflow-hidden">
        {/* Halftone texture */}
        <div className="absolute inset-0 halftone-amber opacity-15 pointer-events-none" />

        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400 text-slate-950 rounded-lg border-2 border-slate-900 font-bangers text-sm sm:text-base tracking-wider mb-3">
            <Sparkles className="w-4 h-4" />
            <span>COMICCRAFT ISSUE #1</span>
          </div>

          <h1 className="font-bangers text-4xl sm:text-6xl text-white tracking-wide uppercase mb-3 drop-shadow-[2px_2px_0px_#f59e0b]">
            {story.title}
          </h1>

          <p className="font-comic italic text-lg sm:text-xl text-amber-200/95 max-w-3xl mb-6">
            "{story.logline}"
          </p>

          {/* Character Profile Card */}
          <div className="bg-slate-800/90 rounded-2xl border-2 border-slate-700 p-4 sm:p-5 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-comic text-slate-300">
            <div>
              <div className="flex items-center gap-1.5 font-bold uppercase text-amber-400 mb-1 text-sm font-bangers">
                <User className="w-4 h-4" />
                <span>HERO: {story.characterProfile.name}</span>
              </div>
              <p>{story.characterProfile.visualAppearance}</p>
            </div>
            <div>
              <div className="font-bold uppercase text-amber-400 mb-1 text-sm font-bangers">
                SIGNATURE ATTIRE
              </div>
              <p>{story.characterProfile.signatureClothing}</p>
            </div>
            <div>
              <div className="font-bold uppercase text-amber-400 mb-1 text-sm font-bangers">
                SETTING & PALETTE
              </div>
              <p>
                <strong className="text-white">{story.input.setting}</strong> · {story.characterProfile.colorPalette}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Sequential 5-Panel Display */}
      <div className="space-y-10 mb-12">
        {localPanels.map((panel) => (
          <ComicPanel
            key={panel.panel_number}
            panel={panel}
            mainCharacterProfile={story.characterProfile}
            setting={story.input.setting}
            artStyle={story.input.artStyle}
            onRegenerateImage={handleRegeneratePanelImage}
            isRegeneratingImage={regeneratingPanelNum === panel.panel_number}
          />
        ))}
      </div>

      {/* The End / Final Comic Banner */}
      <div className="text-center my-10">
        <div className="inline-block px-8 py-3 bg-amber-400 border-4 border-slate-900 rounded-2xl comic-shadow rotate-[-2deg]">
          <span className="font-bangers text-3xl sm:text-4xl text-slate-950 tracking-wider">
            ★ THE END ★
          </span>
        </div>
      </div>

      {/* Bottom Comic Actions */}
      <div className="no-print bg-white rounded-3xl border-4 border-slate-900 comic-shadow-lg p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="font-bangers text-2xl text-slate-900 uppercase">
            Enjoyed this comic?
          </h4>
          <p className="font-comic text-sm text-slate-600">
            Download your full PDF comic issue or craft a brand-new adventure!
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <button
            onClick={handleDownloadPdf}
            disabled={isExportingPdf}
            className="flex-1 sm:flex-none px-5 py-3 bg-red-500 hover:bg-red-400 disabled:opacity-50 text-white font-bangers text-xl tracking-wider rounded-xl border-3 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-5 h-5" />
            <span>{isExportingPdf ? 'CREATING PDF...' : 'DOWNLOAD PDF'}</span>
          </button>

          <button
            onClick={onRegenerate}
            disabled={isRegenerating}
            className="flex-1 sm:flex-none px-5 py-3 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bangers text-xl tracking-wider rounded-xl border-3 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCw className={`w-5 h-5 ${isRegenerating ? 'animate-spin' : ''}`} />
            <span>REGENERATE COMIC</span>
          </button>

          <button
            onClick={onNewComic}
            className="flex-1 sm:flex-none px-5 py-3 bg-white hover:bg-slate-100 text-slate-900 font-bangers text-xl tracking-wider rounded-xl border-3 border-slate-900 comic-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Wand2 className="w-5 h-5" />
            <span>START NEW COMIC</span>
          </button>
        </div>
      </div>

      {/* Floating Scroll to Top button */}
      <button
        onClick={scrollToTop}
        className="no-print fixed bottom-6 right-6 p-3 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-2xl border-3 border-slate-900 comic-shadow active:translate-x-0.5 active:translate-y-0.5 transition-all cursor-pointer z-30"
        title="Scroll to top"
        aria-label="Scroll to top"
      >
        <ArrowUp className="w-6 h-6 stroke-[3]" />
      </button>
    </div>
  );
};
