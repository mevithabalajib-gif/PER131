/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ComicPanel as ComicPanelType, CharacterProfile } from '../types/comic';
import { DialogueBubble } from './DialogueBubble';
import { generateSvgComicFallback } from '../utils/svgFallbacks';
import { 
  Maximize2, 
  RotateCw, 
  Quote, 
  Eye, 
  ChevronDown, 
  ChevronUp, 
  Image as ImageIcon,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface ComicPanelProps {
  panel: ComicPanelType;
  mainCharacterProfile: CharacterProfile;
  setting: string;
  artStyle: string;
  onRegenerateImage?: (panelNumber: number, prompt: string) => Promise<void>;
  isRegeneratingImage?: boolean;
}

export const ComicPanel: React.FC<ComicPanelProps> = ({
  panel,
  mainCharacterProfile,
  setting,
  artStyle,
  onRegenerateImage,
  isRegeneratingImage = false,
}) => {
  const [showPrompt, setShowPrompt] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);
  const [imageError, setImageError] = useState(false);

  // If no native imageUrl or error, use our vector comic fallback
  const fallbackSvgUrl = generateSvgComicFallback({
    panelNumber: panel.panel_number,
    title: panel.title,
    setting,
    artStyle,
    characterName: mainCharacterProfile.name,
    sceneDescription: panel.scene_description,
  });

  const effectiveImageUrl = (panel.imageUrl && !imageError) ? panel.imageUrl : fallbackSvgUrl;
  const isFallback = !panel.imageUrl || imageError || panel.imageStatus === 'fallback';

  const handleRetryImage = () => {
    if (onRegenerateImage) {
      setImageError(false);
      onRegenerateImage(panel.panel_number, panel.image_prompt);
    }
  };

  return (
    <>
      <article className="comic-panel-print bg-white rounded-2xl border-4 border-slate-900 comic-shadow-lg overflow-hidden transition-all hover:translate-y-[-2px]">
        {/* Panel Header Ribbon */}
        <div className="bg-slate-900 text-white px-4 py-2.5 sm:px-6 flex items-center justify-between border-b-3 border-slate-900">
          <div className="flex items-center gap-3">
            <span className="font-bangers text-xl sm:text-2xl text-amber-400 tracking-wider">
              PANEL {panel.panel_number}
            </span>
            <span className="text-slate-500 font-bold hidden sm:inline">|</span>
            <h3 className="font-bangers text-lg sm:text-xl text-white tracking-wide uppercase truncate max-w-[280px] sm:max-w-md">
              {panel.title}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsZoomed(true)}
              className="p-1.5 text-slate-300 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Expand illustration"
              aria-label="Expand illustration"
            >
              <Maximize2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Panel Content Body */}
        <div className="p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Illustration Column (5 or 6 cols on lg) */}
          <div className="lg:col-span-6 flex flex-col gap-3">
            <div className="relative group rounded-xl overflow-hidden border-3 border-slate-900 bg-slate-950 aspect-[4/3] flex items-center justify-center shadow-inner">
              <img
                src={effectiveImageUrl}
                alt={`Comic Panel ${panel.panel_number}: ${panel.title}`}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-102"
                referrerPolicy="no-referrer"
                onError={() => setImageError(true)}
              />

              {/* Hover overlay with zoom button */}
              <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 backdrop-blur-[2px]">
                <button
                  onClick={() => setIsZoomed(true)}
                  className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs rounded-lg border-2 border-slate-900 comic-shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Fullsize</span>
                </button>
              </div>

              {/* Loading overlay during single panel regeneration */}
              {isRegeneratingImage && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center p-4 text-center">
                  <RotateCw className="w-8 h-8 text-amber-400 animate-spin mb-2" />
                  <p className="text-white font-bangers text-lg tracking-wide">
                    GENERATING NEW ARTWORK...
                  </p>
                </div>
              )}
            </div>

            {/* Image Status / Model Notice */}
            <div className="flex items-center justify-between text-xs px-1">
              <div className="flex items-center gap-1.5 text-slate-500">
                {isFallback ? (
                  <span className="inline-flex items-center gap-1 text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-medium text-[11px]">
                    <Sparkles className="w-3 h-3 text-amber-600" />
                    <span>Stylized Vector Artwork</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-medium text-[11px]">
                    <Sparkles className="w-3 h-3 text-emerald-600" />
                    <span>Gemini AI Illustration</span>
                  </span>
                )}
              </div>

              {onRegenerateImage && (
                <button
                  onClick={handleRetryImage}
                  disabled={isRegeneratingImage}
                  className="inline-flex items-center gap-1 text-xs font-bold text-slate-700 hover:text-amber-600 disabled:opacity-50 cursor-pointer transition-colors"
                  title="Generate a new illustration for this panel"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isRegeneratingImage ? 'animate-spin' : ''}`} />
                  <span>Reroll Art</span>
                </button>
              )}
            </div>
          </div>

          {/* Story & Dialogue Column (6 or 7 cols on lg) */}
          <div className="lg:col-span-6 flex flex-col justify-between h-full space-y-4">
            <div>
              {/* Narrator Caption Box (Classic comic yellow ribbon) */}
              {panel.narration && (
                <div className="relative mb-4 bg-amber-100/90 border-2 border-slate-900 rounded-xl p-3.5 comic-shadow-sm">
                  <div className="flex items-center gap-1 text-[11px] font-bold font-bangers tracking-wider text-amber-800 uppercase mb-1">
                    <Quote className="w-3 h-3" />
                    <span>NARRATOR</span>
                  </div>
                  <p className="font-comic italic text-slate-800 text-sm sm:text-base leading-snug">
                    "{panel.narration}"
                  </p>
                </div>
              )}

              {/* Dialogue Bubbles */}
              {panel.dialogue && panel.dialogue.length > 0 && (
                <div className="space-y-1 mb-4">
                  {panel.dialogue.map((d, idx) => {
                    const isMain = d.character.toLowerCase().trim() === mainCharacterProfile.name.toLowerCase().trim();
                    return (
                      <DialogueBubble
                        key={idx}
                        character={d.character}
                        text={d.text}
                        isMainCharacter={isMain}
                      />
                    );
                  })}
                </div>
              )}

              {/* Scene Visual Description */}
              {panel.scene_description && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-600">
                  <span className="font-bold text-slate-800 uppercase mr-1">Scene:</span>
                  <span>{panel.scene_description}</span>
                </div>
              )}
            </div>

            {/* Prompt details accordion */}
            <div className="border-t border-slate-100 pt-3">
              <button
                onClick={() => setShowPrompt(!showPrompt)}
                className="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                <span>Illustration Prompt</span>
                {showPrompt ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>

              {showPrompt && (
                <div className="mt-2 p-2.5 bg-slate-900 text-slate-300 rounded-lg text-[11px] font-mono leading-relaxed border border-slate-700">
                  {panel.image_prompt}
                </div>
              )}
            </div>
          </div>
        </div>
      </article>

      {/* Fullscreen Lightbox Modal */}
      {isZoomed && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setIsZoomed(false)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh] bg-white rounded-2xl border-4 border-slate-900 comic-shadow-lg p-2 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-3 py-2 border-b-2 border-slate-900 mb-2">
              <h4 className="font-bangers text-xl text-slate-900">
                PANEL {panel.panel_number}: {panel.title}
              </h4>
              <button
                onClick={() => setIsZoomed(false)}
                className="px-2.5 py-1 bg-red-500 hover:bg-red-600 text-white font-bold text-xs rounded border border-slate-900 cursor-pointer"
              >
                ✕ Close
              </button>
            </div>
            <div className="max-h-[75vh] overflow-auto flex items-center justify-center">
              <img
                src={effectiveImageUrl}
                alt={panel.title}
                className="max-h-[72vh] w-auto object-contain rounded-lg border-2 border-slate-900"
                referrerPolicy="no-referrer"
              />
            </div>
            <p className="text-xs text-slate-600 text-center py-2 font-comic">
              {panel.scene_description}
            </p>
          </div>
        </div>
      )}
    </>
  );
};
