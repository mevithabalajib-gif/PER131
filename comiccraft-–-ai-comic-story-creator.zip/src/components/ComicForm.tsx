/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ComicInput } from '../types/comic';
import { SETTINGS, TONES, ART_STYLES, EXAMPLE_STORIES } from '../utils/comicThemes';
import { Wand2, Sparkles, Lightbulb, User, MapPin, Smile, Palette, ArrowRight } from 'lucide-react';

interface ComicFormProps {
  onSubmit: (input: ComicInput) => void;
  isLoading: boolean;
  initialValues?: Partial<ComicInput>;
}

export const ComicForm: React.FC<ComicFormProps> = ({
  onSubmit,
  isLoading,
  initialValues,
}) => {
  const [storyPrompt, setStoryPrompt] = useState(initialValues?.storyPrompt || '');
  const [characterName, setCharacterName] = useState(initialValues?.characterName || '');
  const [setting, setSetting] = useState(initialValues?.setting || 'Forest');
  const [tone, setTone] = useState(initialValues?.tone || 'Adventure');
  const [artStyle, setArtStyle] = useState(initialValues?.artStyle || 'Comic Book');
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    const trimmedPrompt = storyPrompt.trim();
    const trimmedChar = characterName.trim();

    if (!trimmedPrompt) {
      setValidationError('Please enter a story idea or prompt for your comic.');
      return;
    }
    if (trimmedPrompt.length < 10) {
      setValidationError('Please provide a slightly more descriptive story prompt (at least 10 characters).');
      return;
    }
    if (!trimmedChar) {
      setValidationError('Please enter a name for your main character.');
      return;
    }
    if (!setting) {
      setValidationError('Please select a setting for your comic.');
      return;
    }
    if (!tone) {
      setValidationError('Please select a story tone.');
      return;
    }
    if (!artStyle) {
      setValidationError('Please select an art style.');
      return;
    }

    onSubmit({
      storyPrompt: trimmedPrompt,
      characterName: trimmedChar,
      setting,
      tone,
      artStyle,
    });
  };

  const loadExample = (example: typeof EXAMPLE_STORIES[0]) => {
    setStoryPrompt(example.prompt);
    setCharacterName(example.characterName);
    setSetting(example.setting);
    setTone(example.tone);
    setArtStyle(example.artStyle);
    setValidationError(null);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8">
      {/* Hero Welcome Banner */}
      <div className="text-center mb-8 sm:mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100 border-2 border-slate-900 rounded-full text-xs font-bold font-mono uppercase text-slate-800 mb-4 comic-shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          <span>Powered by Google Gemini Models</span>
        </div>

        <h1 className="font-bangers text-4xl sm:text-6xl text-slate-900 tracking-wide mb-3 leading-none drop-shadow-[2px_2px_0px_#f59e0b]">
          CREATE YOUR OWN 5-PANEL COMIC
        </h1>
        <p className="text-base sm:text-lg text-slate-600 font-comic max-w-2xl mx-auto leading-relaxed">
          Type your wildest story idea. We will generate the narrative outline, character dialogue, panel scripts, and complete illustrations in true comic-book style!
        </p>

        {/* Quick Inspiration Pills */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1 mr-1">
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" /> Try an example:
          </span>
          {EXAMPLE_STORIES.map((ex, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => loadExample(ex)}
              className="text-xs font-medium px-3 py-1.5 bg-white hover:bg-amber-100 text-slate-800 rounded-lg border-2 border-slate-900 comic-shadow-sm transition-all hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
            >
              {ex.title}
            </button>
          ))}
        </div>
      </div>

      {/* Main Comic Creator Form Card */}
      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-3xl border-4 border-slate-900 comic-shadow-lg p-6 sm:p-10 relative overflow-hidden"
      >
        {/* Halftone texture overlay */}
        <div className="absolute top-0 right-0 w-48 h-48 halftone-amber opacity-30 pointer-events-none rounded-tr-2xl" />

        {validationError && (
          <div className="mb-6 p-4 bg-red-50 border-2 border-red-500 rounded-xl text-red-700 text-sm font-bold flex items-center gap-2">
            <span>⚠️</span>
            <span>{validationError}</span>
          </div>
        )}

        <div className="space-y-6">
          {/* 1. Story Prompt (Large textarea) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label
                htmlFor="storyPrompt"
                className="font-bangers text-xl sm:text-2xl text-slate-900 tracking-wide flex items-center gap-2"
              >
                <span>1. STORY PROMPT / MAIN IDEA</span>
                <span className="text-red-500">*</span>
              </label>
              <span className="text-xs font-mono text-slate-400">
                {storyPrompt.length}/1000
              </span>
            </div>
            <textarea
              id="storyPrompt"
              value={storyPrompt}
              onChange={(e) => setStoryPrompt(e.target.value)}
              maxLength={1000}
              rows={4}
              placeholder="e.g. A brave fox discovers a mysterious glowing door in an enchanted forest and steps into a lost civilization..."
              className="w-full p-4 rounded-xl border-3 border-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-300 font-comic text-base text-slate-900 placeholder:text-slate-400 bg-amber-50/20 resize-y leading-relaxed transition-all"
              required
            />
            <p className="text-xs text-slate-500 mt-1 font-comic">
              💡 Describe what happens, key discoveries, or conflicts. Gemini will shape it into a 5-panel story arc!
            </p>
          </div>

          {/* 2. Character Name */}
          <div>
            <label
              htmlFor="characterName"
              className="font-bangers text-xl sm:text-2xl text-slate-900 tracking-wide flex items-center gap-2 mb-2"
            >
              <User className="w-5 h-5 text-amber-500" />
              <span>2. MAIN CHARACTER NAME</span>
              <span className="text-red-500">*</span>
            </label>
            <input
              id="characterName"
              type="text"
              value={characterName}
              onChange={(e) => setCharacterName(e.target.value)}
              placeholder="e.g. Luna the Fox, Captain Orion, Maya, Jax"
              maxLength={50}
              className="w-full p-3.5 rounded-xl border-3 border-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-300 font-comic text-base text-slate-900 placeholder:text-slate-400 bg-white transition-all"
              required
            />
          </div>

          {/* 3. Setting, Tone, and Art Style Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            {/* Setting Dropdown */}
            <div>
              <label
                htmlFor="setting"
                className="font-bangers text-lg sm:text-xl text-slate-900 tracking-wide flex items-center gap-1.5 mb-2"
              >
                <MapPin className="w-4 h-4 text-emerald-600" />
                <span>3. SETTING</span>
              </label>
              <select
                id="setting"
                value={setting}
                onChange={(e) => setSetting(e.target.value)}
                className="w-full p-3.5 rounded-xl border-3 border-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-300 font-comic text-sm font-bold text-slate-900 bg-white cursor-pointer"
              >
                {SETTINGS.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 mt-1 font-comic">
                {SETTINGS.find((s) => s.id === setting)?.description}
              </p>
            </div>

            {/* Story Tone Dropdown */}
            <div>
              <label
                htmlFor="tone"
                className="font-bangers text-lg sm:text-xl text-slate-900 tracking-wide flex items-center gap-1.5 mb-2"
              >
                <Smile className="w-4 h-4 text-amber-500" />
                <span>4. STORY TONE</span>
              </label>
              <select
                id="tone"
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full p-3.5 rounded-xl border-3 border-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-300 font-comic text-sm font-bold text-slate-900 bg-white cursor-pointer"
              >
                {TONES.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 mt-1 font-comic">
                {TONES.find((t) => t.id === tone)?.description}
              </p>
            </div>

            {/* Art Style Dropdown */}
            <div>
              <label
                htmlFor="artStyle"
                className="font-bangers text-lg sm:text-xl text-slate-900 tracking-wide flex items-center gap-1.5 mb-2"
              >
                <Palette className="w-4 h-4 text-indigo-600" />
                <span>5. ART STYLE</span>
              </label>
              <select
                id="artStyle"
                value={artStyle}
                onChange={(e) => setArtStyle(e.target.value)}
                className="w-full p-3.5 rounded-xl border-3 border-slate-900 focus:outline-none focus:ring-4 focus:ring-amber-300 font-comic text-sm font-bold text-slate-900 bg-white cursor-pointer"
              >
                {ART_STYLES.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.name}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-slate-500 mt-1 font-comic">
                {ART_STYLES.find((a) => a.id === artStyle)?.description}
              </p>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-4 px-6 bg-amber-400 hover:bg-amber-300 disabled:bg-slate-300 disabled:cursor-not-allowed text-slate-950 font-bangers text-2xl sm:text-3xl tracking-wider rounded-2xl border-4 border-slate-900 comic-shadow hover:comic-shadow-lg active:translate-x-1 active:translate-y-1 transition-all flex items-center justify-center gap-3 cursor-pointer group"
            >
              <Wand2 className="w-7 h-7 group-hover:rotate-12 transition-transform" />
              <span>{isLoading ? 'GENERATING YOUR COMIC...' : 'CREATE MY COMIC'}</span>
              <ArrowRight className="w-7 h-7 group-hover:translate-x-1 transition-transform" />
            </button>
            <p className="text-center text-xs text-slate-500 mt-2 font-comic">
              Takes ~15-25 seconds to generate complete narrative, 5 panel scripts, dialogue, and illustrations.
            </p>
          </div>
        </div>
      </form>
    </div>
  );
};
